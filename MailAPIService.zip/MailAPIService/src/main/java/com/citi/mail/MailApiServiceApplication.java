package com.citi.mail;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MailApiServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MailApiServiceApplication.class, args);
	}

}
